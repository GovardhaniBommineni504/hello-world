package com.cts1;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/savedata")  
@Controller  
public class ReservationController {
	@RequestMapping("/registerdata")  
	public String bookingForm(Model model)  
	{  
	      //create a reservation object   
	    ITPpojo res=new ITPpojo();  
	      //provide reservation object to the model   
	    model.addAttribute("savedata", res);  
	    return "register1";  
	}  
	@RequestMapping("/submitForm")  
	// @ModelAttribute binds form data to the object  
	public String submitForm(@ModelAttribute("savedata") ITPpojo res)  
	{  
	    return "confirmation-form";  
	}  
	}  

