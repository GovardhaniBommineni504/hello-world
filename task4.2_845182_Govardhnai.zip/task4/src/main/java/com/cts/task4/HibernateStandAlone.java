package com.cts.task4;

import java.util.List;

import org.hibernate.Session;

import com.model.Address;
import com.model.Student;

public class HibernateStandAlone {
	
	 @SuppressWarnings("unchecked")
	    public static void main(String[] args) {
	 
	        Student student = new Student("Govardhani","Bommineni","PAT");
	        Address address = new Address("Thakkellapadu","Ongole","AP");
	         
	         
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        session.beginTransaction();
	 
	        session.persist(address);
	        student.setAddress(address);
	        session.persist(student);
	 
	        List<Student> students = (List<Student>)session.createQuery("from Student ").list();
	        for(Student s: students){
	            System.out.println("Details : "+s);
	        }
	         
	        session.getTransaction().commit();
	        session.close();  
	    }
	 

}
